const express = require('express')//importando o módulo express
const expphbs = require('express-handlebars')//importando o módulo handlebars

const app = express()

app.engine('handlebars', expphbs.engine())
app.set('view engine','handlebars')

app.use(express.static('public'))

app.get('/', (req,res) => {
    res.render('com_cadastro/home')
})

/* Ensino Médio */

app.get('/1em', (req,res) => {
    res.render('com_cadastro/menu_ensino_medio/1em')
})

app.get('/2em', (req,res) => {
    res.render('com_cadastro/menu_ensino_medio/2em')
})

app.get('/3em', (req,res) => {
    res.render('com_cadastro/menu_ensino_medio/3em')
})

/* Menu Lateral */

app.get('/deaaz', (req,res) => {
    res.render('com_cadastro/menu_lateral/deaaz')
})

app.get('/comousarsuanotadoenem', (req,res) => {
    res.render('com_cadastro/menu_lateral/comousarsuanotadoenem')
})

app.get('/redacoes', (req,res) => {
    res.render('com_cadastro/menu_lateral/redacoes')
})

app.get('/testesvocacionais', (req,res) => {
    res.render('com_cadastro/menu_lateral/testesvocacionais')
})

app.get('/tecnicasdeestudo', (req,res) => {
    res.render('com_cadastro/menu_lateral/tecnicasdeestudo')
})

app.get('/musicaseprogramas', (req,res) => {
    res.render('com_cadastro/menu_lateral/musicaseprogramas')
})

app.get('/filmes', (req,res) => {
    res.render('com_cadastro/menu_lateral/filmes')
})

app.get('/duvidas', (req,res) => {
    res.render('com_cadastro/menu_lateral/duvidas')
})

app.get('/dicionario', (req,res) => {
    res.render('com_cadastro/menu_lateral/dicionario')
})

app.get('/sobrenos', (req,res) => {
    res.render('com_cadastro/menu_lateral/sobrenos')
})

/* Páginas das Matérias */

app.get('/matematica', (req,res) => {
    res.render('com_cadastro/menu_materias/matematica')
})

app.get('/portugues', (req,res) => {
    res.render('com_cadastro/menu_materias/portugues')
})

app.get('/geografia', (req,res) => {
    res.render('com_cadastro/menu_materias/geografia')
})

app.get('/historia', (req,res) => {
    res.render('com_cadastro/menu_materias/historia')
})

app.get('/biologia', (req,res) => {
    res.render('com_cadastro/menu_materias/biologia')
})

app.get('/quimica', (req,res) => {
    res.render('com_cadastro/menu_materias/quimica')
})

app.get('/fisica', (req,res) => {
    res.render('com_cadastro/menu_materias/fisica')
})

app.get('/artes', (req,res) => {
    res.render('com_cadastro/menu_materias/artes')
})

/* Login e Cadastro */

app.get('/login', (req,res) => {
    res.render('com_cadastro/login_cadastro/login', {layout: 'entrar.handlebars'})
})

app.get('/cadastro', (req,res) => {
    res.render('com_cadastro/login_cadastro/cadastro', {layout: 'cadastrar.handlebars'})
})

/* ____________________________________________________________________________________________ */
/* Páginas para usuários sem cadastro */

app.get('/homesimples', (req,res) => {
    res.render('sem_cadastro/s_cad_home', {layout: 's_cad_main.handlebars'})
})

app.get('/1emsimples', (req,res) => {
    res.render('sem_cadastro/menus/s_cad_1em', {layout: 's_cad_main.handlebars'})
})

app.get('/2emsimples', (req,res) => {
    res.render('sem_cadastro/menus/s_cad_2em', {layout: 's_cad_main.handlebars'})
})

app.get('/3emsimples', (req,res) => {
    res.render('sem_cadastro/menus/s_cad_3em', {layout: 's_cad_main.handlebars'})
})

app.get('/sobrenossimples', (req,res) => {
    res.render('sem_cadastro/menus/s_cad_sobrenos', {layout: 's_cad_main.handlebars'})
})

app.get('/cadastrosimples', (req,res) => {
    res.render('sem_cadastro/s_login_cadastro/s_cad_cadastro', {layout: 's_cad_cadastrar.handlebars'})
})

app.get('/loginsimples', (req,res) => {
    res.render('sem_cadastro/s_login_cadastro/s_cad_login', {layout: 's_cad_entrar.handlebars'})
})

/* App */

app.listen(3000, () => {
    console.log('App Funcionando!')
})